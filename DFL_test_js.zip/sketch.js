let ref_freq = 750
let step = ref_freq/4

let test_freq = ref_freq+step;

let trialtype;

let diff = ref_freq-test_freq

let i = 0
let n_pres = 20

let my_r = 0

let table;
table = new p5.Table();

function play_sound(){
  
  my_r = random([0, 1, 2]);
  
  if (i > n_pres){print('Test ended')}
  
  //SAME Trial
  else if (my_r == 0){
    trialtype = 'same'

    osc.start(0, ref_freq)
    osc.stop(1)
    setTimeout(function(){
        osc.start(0, ref_freq)
        osc.stop(1)
    }, 2000);


    print('Trial:' + (i+1) + ', Reference f:' + ref_freq + ', Test f:' + ref_freq + ', Step:' + 0)
  }

  //DIFFERENT Trial
  else if (my_r > 0){
  trialtype = 'different'
    
  osc.start(0, ref_freq)
  osc.stop(1)
  setTimeout(function(){
      osc.start(0, test_freq)
      osc.stop(1)
  }, 2000);
    
  print('Trial:' + (i+1) + ', Reference f:' + ref_freq + ', Test f:' + test_freq + ', Step:' + step)
  }
  
  i++
  
}

function diff_resp() {
  
  //Correct DIFFERENT
  if (trialtype == 'different'){
    
    let newRow = table.addRow();
    newRow.setNum('trial_n', i);
    newRow.setString('trial_type', 'Different');
    newRow.setString('response', 'Different');
    newRow.setNum('reference_freq', ref_freq);
    newRow.setNum('test_freq', test_freq);
    
    step = round(step*0.75,0)
    
    my_r = random([0, 1]);
    if (my_r == 1){test_freq = ref_freq + step}
    if (my_r == 0){test_freq = ref_freq - step}
  }
  
  //INCORRECT DIFFERENT
  else if (trialtype == 'same'){

    let newRow = table.addRow();
    newRow.setNum('trial_n', i);
    newRow.setString('trial_type', 'Same');
    newRow.setString('response', 'Different');
    newRow.setNum('reference_freq', ref_freq);
    newRow.setNum('test_freq', test_freq);
  }
  
  play_sound()
}

function same_resp() {
  
    //Correct SAME
    if (trialtype == 'same'){
      
      let newRow = table.addRow();
      newRow.setNum('trial_n', i);
      newRow.setString('trial_type', 'Same');
      newRow.setString('response', 'Same');
      newRow.setNum('reference_freq', ref_freq);
      newRow.setNum('test_freq', ref_freq);
      
    }
  
    //Incorrect SAME
    else if (trialtype == 'different'){
      
      let newRow = table.addRow();
      newRow.setNum('trial_n', i);
      newRow.setString('trial_type', 'Different');
      newRow.setString('response', 'Same');
      newRow.setNum('reference_freq', ref_freq);
      newRow.setNum('test_freq', test_freq);
      
      step = round(step*1.25,0)
      
      my_r = random([0, 1]);
      if (my_r == 1){test_freq = ref_freq + step}
      if (my_r == 0){test_freq = ref_freq - step}
    }
  
  play_sound()
}

function save_csv(){saveTable(table, 'new.csv');}

function setup() {
  createCanvas(400, 400);
  
  table.addColumn('trial_n')
  table.addColumn('trial_type')
  table.addColumn('response');
  table.addColumn('reference_freq');
  table.addColumn('test_freq');
  
  if (random([0, 1]) == 1){test_freq = ref_freq + step}
  if (random([0, 1]) == 0){test_freq = ref_freq - step}
  
  button1 = createButton('DIFFERENT');
  button1.position(50, 100);
  button1.size(100,100)
  button1.mousePressed(diff_resp);
  
  button2 = createButton('SAME');
  button2.position(250, 100);
  button2.size(100,100)
  button2.mousePressed(same_resp);
  
  button3 = createButton('Save results as CSV');
  button3.position(150, 300);
  button3.size(100,50)
  button3.mousePressed(save_csv);
  
  osc = new p5.Oscillator('sine');
  
}

function draw() {
  background(255);
  
  button3 = createButton('Start test');
  button3.position(150, 25);
  button3.size(100,25)
  button3.mousePressed(play_sound);

}

